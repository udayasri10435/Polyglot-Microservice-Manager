export interface Service {
  id: string;
  name: string;
  domain: string;
  language: string;
  status: 'Healthy' | 'Warning' | 'Critical';
  version: string;
  latency: number;
  errorRate: string;
  cpu: number;
  memory: number;
  lastDeployed: string;
}

export interface ServiceResponse {
  total: number;
  services: Service[];
  page: number;
  totalPages: number;
}

export interface Stats {
  langStats: { name: string; count: number }[];
  domainStats: { name: string; count: number }[];
  statusStats: {
    Healthy: number;
    Warning: number;
    Critical: number;
  };
}

export interface Deployment {
  id: string;
  version: string;
  deployer: string;
  timestamp: string;
  status: 'Current' | 'Superseded';
}
