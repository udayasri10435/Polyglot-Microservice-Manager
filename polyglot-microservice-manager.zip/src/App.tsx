import React, { useState, useEffect, useMemo } from 'react';
import { 
  Activity, 
  Box, 
  Cpu, 
  Database, 
  Globe, 
  LayoutDashboard, 
  Layers, 
  Search, 
  Server, 
  Shield, 
  Zap,
  ChevronLeft,
  ChevronRight,
  Filter,
  RefreshCw,
  Terminal,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Settings,
  BarChart3
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { cn, formatBytes, formatDate } from './lib/utils';
import { Service, ServiceResponse, Stats, Deployment } from './types';

const DOMAINS = [
  "Human Resources", "Finance", "Project Management", 
  "CRM", "Supply Chain", "IT Infrastructure", "Analytics"
];

const LANGUAGES = [
  "Java", "Kotlin", "Go", "Python", "Node.js", 
  "TypeScript", "Rust", "C#", "Elixir", "Scala"
];

export default function App() {
  const [view, setView] = useState<'dashboard' | 'inventory' | 'topology'>('dashboard');
  const [services, setServices] = useState<Service[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({
    domain: '',
    language: '',
    status: ''
  });
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [deployments, setDeployments] = useState<Deployment[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'deployments'>('overview');

  const fetchData = async () => {
    setLoading(true);
    try {
      const query = new URLSearchParams({
        page: page.toString(),
        search,
        ...filters
      }).toString();
      
      const [svcRes, statsRes] = await Promise.all([
        fetch(`/api/services?${query}`),
        fetch('/api/stats')
      ]);
      
      const svcData: ServiceResponse = await svcRes.json();
      const statsData: Stats = await statsRes.json();
      
      setServices(svcData.services);
      setTotalPages(svcData.totalPages);
      setStats(statsData);
    } catch (error) {
      console.error('Failed to fetch data', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [page, search, filters]);

  useEffect(() => {
    if (selectedService) {
      const fetchDeployments = async () => {
        try {
          const res = await fetch(`/api/services/${selectedService.id}/versions`);
          const data = await res.json();
          setDeployments(data);
        } catch (error) {
          console.error('Failed to fetch deployments', error);
        }
      };
      fetchDeployments();
      setActiveTab('overview');
    } else {
      setDeployments([]);
    }
  }, [selectedService]);

  const handleAction = async (id: string, action: string) => {
    try {
      await fetch(`/api/services/${id}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action })
      });
      alert(`Action ${action} triggered for ${id}`);
    } catch (error) {
      console.error('Action failed', error);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-[var(--color-line)] flex flex-col bg-[var(--color-bg)] z-20">
        <div className="p-6 border-b border-[var(--color-line)]">
          <div className="flex items-center gap-2 mb-1">
            <Layers className="w-6 h-6" />
            <h1 className="font-serif font-bold text-xl tracking-tight">Polyglot</h1>
          </div>
          <p className="text-[10px] uppercase tracking-[0.2em] opacity-50 font-mono">Mission Control v1.0</p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <NavItem 
            active={view === 'dashboard'} 
            onClick={() => setView('dashboard')} 
            icon={<LayoutDashboard className="w-4 h-4" />} 
            label="Dashboard" 
          />
          <NavItem 
            active={view === 'inventory'} 
            onClick={() => setView('inventory')} 
            icon={<Server className="w-4 h-4" />} 
            label="Service Inventory" 
          />
          <NavItem 
            active={view === 'topology'} 
            onClick={() => setView('topology')} 
            icon={<Globe className="w-4 h-4" />} 
            label="System Topology" 
          />
          <div className="pt-4 mt-4 border-t border-[var(--color-line)] opacity-30"></div>
          <NavItem active={false} icon={<Shield className="w-4 h-4" />} label="Security & IAM" />
          <NavItem active={false} icon={<Database className="w-4 h-4" />} label="Persistence" />
          <NavItem active={false} icon={<Settings className="w-4 h-4" />} label="Orchestration" />
        </nav>

        <div className="p-4 border-t border-[var(--color-line)]">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-ink text-bg">
            <div className="w-8 h-8 rounded-full bg-healthy flex items-center justify-center text-ink font-bold text-xs">
              UM
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium truncate">udayasrimadhushan</p>
              <p className="text-[10px] opacity-50 truncate">System Architect</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header */}
        <header className="h-16 border-b border-[var(--color-line)] flex items-center justify-between px-8 bg-[var(--color-bg)]/80 backdrop-blur-sm z-10">
          <div className="flex items-center gap-4">
            <h2 className="font-serif italic text-lg capitalize">{view}</h2>
            <div className="h-4 w-[1px] bg-[var(--color-line)] opacity-20"></div>
            <div className="flex items-center gap-2 text-[10px] font-mono opacity-50">
              <Activity className="w-3 h-3 text-healthy" />
              <span>SYSTEM STATUS: NOMINAL</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 opacity-30" />
              <input 
                type="text" 
                placeholder="Search services..."
                className="pl-9 pr-4 py-1.5 bg-transparent border border-[var(--color-line)] rounded-full text-xs focus:outline-none focus:ring-1 focus:ring-ink w-64"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <button 
              onClick={fetchData}
              className="p-2 hover:bg-ink/5 rounded-full transition-colors"
            >
              <RefreshCw className={cn("w-4 h-4", loading && "animate-spin")} />
            </button>
          </div>
        </header>

        {/* View Content */}
        <div className="flex-1 overflow-y-auto p-8">
          <AnimatePresence mode="wait">
            {view === 'dashboard' && (
              <motion.div 
                key="dashboard"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-8"
              >
                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <StatCard 
                    label="Total Services" 
                    value="1,000" 
                    subValue="Active & Polyglot"
                    icon={<Layers className="w-5 h-5" />}
                  />
                  <StatCard 
                    label="System Health" 
                    value={stats ? `${Math.round((stats.statusStats.Healthy / 1000) * 100)}%` : '...'} 
                    subValue={`${stats?.statusStats.Critical} Critical Alerts`}
                    icon={<Activity className="w-5 h-5" />}
                    trend="down"
                  />
                  <StatCard 
                    label="Avg Latency" 
                    value="42ms" 
                    subValue="Across all regions"
                    icon={<Zap className="w-5 h-5" />}
                    trend="up"
                  />
                  <StatCard 
                    label="Error Rate" 
                    value="0.04%" 
                    subValue="Last 24 hours"
                    icon={<AlertTriangle className="w-5 h-5" />}
                  />
                </div>

                {/* Charts Row */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 p-6 border border-[var(--color-line)] rounded-xl bg-white/50">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="font-serif italic text-sm">Language Distribution</h3>
                      <BarChart3 className="w-4 h-4 opacity-30" />
                    </div>
                    <div className="h-[300px]">
                      {stats && (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={stats.langStats}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#14141410" />
                            <XAxis 
                              dataKey="name" 
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fontSize: 10, fontFamily: 'JetBrains Mono' }} 
                            />
                            <YAxis 
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fontSize: 10, fontFamily: 'JetBrains Mono' }} 
                            />
                            <Tooltip 
                              contentStyle={{ 
                                backgroundColor: '#141414', 
                                border: 'none', 
                                borderRadius: '8px',
                                color: '#E4E3E0',
                                fontSize: '12px',
                                fontFamily: 'JetBrains Mono'
                              }}
                              itemStyle={{ color: '#E4E3E0' }}
                            />
                            <Bar dataKey="count" fill="#141414" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </div>

                  <div className="p-6 border border-[var(--color-line)] rounded-xl bg-white/50">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="font-serif italic text-sm">Health Status</h3>
                      <Shield className="w-4 h-4 opacity-30" />
                    </div>
                    <div className="h-[300px]">
                      {stats && (
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={[
                                { name: 'Healthy', value: stats.statusStats.Healthy },
                                { name: 'Warning', value: stats.statusStats.Warning },
                                { name: 'Critical', value: stats.statusStats.Critical },
                              ]}
                              innerRadius={60}
                              outerRadius={80}
                              paddingAngle={5}
                              dataKey="value"
                            >
                              <Cell fill="var(--color-healthy)" />
                              <Cell fill="var(--color-warning)" />
                              <Cell fill="var(--color-critical)" />
                            </Pie>
                            <Tooltip 
                              contentStyle={{ 
                                backgroundColor: '#141414', 
                                border: 'none', 
                                borderRadius: '8px',
                                color: '#E4E3E0',
                                fontSize: '12px',
                                fontFamily: 'JetBrains Mono'
                              }}
                            />
                          </PieChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                    <div className="mt-4 space-y-2">
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-healthy" /> HEALTHY</span>
                        <span>{stats?.statusStats.Healthy}</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-warning" /> WARNING</span>
                        <span>{stats?.statusStats.Warning}</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-critical" /> CRITICAL</span>
                        <span>{stats?.statusStats.Critical}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Activity / Logs */}
                <div className="p-6 border border-[var(--color-line)] rounded-xl bg-white/50">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="font-serif italic text-sm">System Events</h3>
                    <Terminal className="w-4 h-4 opacity-30" />
                  </div>
                  <div className="space-y-3 font-mono text-[11px]">
                    <div className="flex gap-4 opacity-60">
                      <span className="w-32">2026-03-28 11:31:02</span>
                      <span className="text-healthy">[INFO]</span>
                      <span>Service payroll-tax-calculator-12 deployed successfully.</span>
                    </div>
                    <div className="flex gap-4">
                      <span className="w-32">2026-03-28 11:30:45</span>
                      <span className="text-warning">[WARN]</span>
                      <span>High memory usage detected in analytics-engine-402.</span>
                    </div>
                    <div className="flex gap-4">
                      <span className="w-32">2026-03-28 11:29:12</span>
                      <span className="text-critical">[ERR]</span>
                      <span>Connection timeout: crm-sync-service-88 to db-cluster-01.</span>
                    </div>
                    <div className="flex gap-4 opacity-60">
                      <span className="w-32">2026-03-28 11:28:55</span>
                      <span className="text-healthy">[INFO]</span>
                      <span>Auto-scaling triggered for hr-portal-api-5. New replica added.</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {view === 'inventory' && (
              <motion.div 
                key="inventory"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                {/* Filters */}
                <div className="flex flex-wrap gap-4 items-center p-4 border border-[var(--color-line)] rounded-xl bg-white/30">
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4 opacity-50" />
                    <span className="text-[10px] font-mono uppercase tracking-wider">Filters:</span>
                  </div>
                  
                  <select 
                    className="bg-transparent border border-[var(--color-line)] rounded-md px-3 py-1 text-xs focus:outline-none"
                    value={filters.domain}
                    onChange={(e) => setFilters(prev => ({ ...prev, domain: e.target.value }))}
                  >
                    <option value="">All Domains</option>
                    {DOMAINS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>

                  <select 
                    className="bg-transparent border border-[var(--color-line)] rounded-md px-3 py-1 text-xs focus:outline-none"
                    value={filters.language}
                    onChange={(e) => setFilters(prev => ({ ...prev, language: e.target.value }))}
                  >
                    <option value="">All Languages</option>
                    {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>

                  <select 
                    className="bg-transparent border border-[var(--color-line)] rounded-md px-3 py-1 text-xs focus:outline-none"
                    value={filters.status}
                    onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value }))}
                  >
                    <option value="">All Statuses</option>
                    <option value="Healthy">Healthy</option>
                    <option value="Warning">Warning</option>
                    <option value="Critical">Critical</option>
                  </select>

                  <button 
                    onClick={() => {
                      setFilters({ domain: '', language: '', status: '' });
                      setSearch('');
                    }}
                    className="text-[10px] font-mono uppercase underline opacity-50 hover:opacity-100"
                  >
                    Reset
                  </button>
                </div>

                {/* Table */}
                <div className="border border-[var(--color-line)] rounded-xl overflow-hidden bg-white/50">
                  <div className="grid grid-cols-12 p-4 border-b border-[var(--color-line)] bg-ink/5">
                    <div className="col-span-1 col-header">ID</div>
                    <div className="col-span-3 col-header">Service Name</div>
                    <div className="col-span-2 col-header">Domain</div>
                    <div className="col-span-1 col-header">Language</div>
                    <div className="col-span-1 col-header">Status</div>
                    <div className="col-span-1 col-header">Latency</div>
                    <div className="col-span-1 col-header">Error %</div>
                    <div className="col-span-2 col-header text-right">Last Deployed</div>
                  </div>

                  <div className="divide-y divide-[var(--color-line)]">
                    {services.map((svc) => (
                      <div 
                        key={svc.id} 
                        className="grid grid-cols-12 p-4 data-row items-center"
                        onClick={() => setSelectedService(svc)}
                      >
                        <div className="col-span-1 data-value text-[10px] opacity-50">{svc.id}</div>
                        <div className="col-span-3 font-medium text-xs">{svc.name}</div>
                        <div className="col-span-2 text-[10px] font-mono opacity-70">{svc.domain}</div>
                        <div className="col-span-1">
                          <span className="px-2 py-0.5 rounded-full border border-[var(--color-line)] text-[9px] font-mono">
                            {svc.language}
                          </span>
                        </div>
                        <div className="col-span-1">
                          <div className={cn(
                            "w-2 h-2 rounded-full",
                            svc.status === 'Healthy' ? 'bg-healthy' : 
                            svc.status === 'Warning' ? 'bg-warning' : 'bg-critical'
                          )} />
                        </div>
                        <div className="col-span-1 data-value text-[10px]">{svc.latency}ms</div>
                        <div className="col-span-1 data-value text-[10px]">{svc.errorRate}%</div>
                        <div className="col-span-2 data-value text-[9px] text-right opacity-50">
                          {formatDate(svc.lastDeployed)}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Pagination */}
                  <div className="p-4 flex items-center justify-between border-t border-[var(--color-line)] bg-ink/5">
                    <span className="text-[10px] font-mono opacity-50">
                      Showing page {page} of {totalPages}
                    </span>
                    <div className="flex gap-2">
                      <button 
                        disabled={page === 1}
                        onClick={() => setPage(p => Math.max(1, p - 1))}
                        className="p-1 border border-[var(--color-line)] rounded hover:bg-ink hover:text-bg disabled:opacity-20 transition-colors"
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </button>
                      <button 
                        disabled={page === totalPages}
                        onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                        className="p-1 border border-[var(--color-line)] rounded hover:bg-ink hover:text-bg disabled:opacity-20 transition-colors"
                      >
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {view === 'topology' && (
              <motion.div 
                key="topology"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="h-full flex flex-col items-center justify-center text-center space-y-6"
              >
                <div className="w-24 h-24 rounded-full border-2 border-dashed border-[var(--color-line)] flex items-center justify-center animate-spin-slow">
                  <Globe className="w-12 h-12 opacity-20" />
                </div>
                <div>
                  <h3 className="font-serif italic text-xl">Global Topology View</h3>
                  <p className="text-xs opacity-50 max-w-md mx-auto mt-2">
                    Visualizing 1,000 services and their inter-dependencies. 
                    The system mesh is currently processing 14.2k requests/sec.
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-8 w-full max-w-2xl">
                  <div className="p-4 border border-[var(--color-line)] rounded-xl">
                    <div className="text-[10px] font-mono opacity-50 mb-1">NODES</div>
                    <div className="text-2xl font-serif">1,000</div>
                  </div>
                  <div className="p-4 border border-[var(--color-line)] rounded-xl">
                    <div className="text-[10px] font-mono opacity-50 mb-1">EDGES</div>
                    <div className="text-2xl font-serif">8,421</div>
                  </div>
                  <div className="p-4 border border-[var(--color-line)] rounded-xl">
                    <div className="text-[10px] font-mono opacity-50 mb-1">CLUSTERS</div>
                    <div className="text-2xl font-serif">12</div>
                  </div>
                </div>
                <button className="px-6 py-2 bg-ink text-bg rounded-full text-xs font-medium hover:opacity-90 transition-opacity">
                  Initialize 3D Visualization
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Service Detail Modal */}
      <AnimatePresence>
        {selectedService && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedService(null)}
              className="fixed inset-0 bg-ink/40 backdrop-blur-sm z-40"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-[450px] bg-[var(--color-bg)] border-l border-[var(--color-line)] z-50 shadow-2xl flex flex-col"
            >
              <div className="p-8 border-b border-[var(--color-line)]">
                <div className="flex items-center justify-between mb-6">
                  <span className="px-3 py-1 bg-ink text-bg text-[10px] font-mono rounded-full">
                    {selectedService.id}
                  </span>
                  <button onClick={() => setSelectedService(null)} className="p-2 hover:bg-ink/5 rounded-full">
                    <XCircle className="w-5 h-5" />
                  </button>
                </div>
                <h2 className="text-3xl font-serif font-bold mb-2">{selectedService.name}</h2>
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-2 h-2 rounded-full",
                    selectedService.status === 'Healthy' ? 'bg-healthy' : 
                    selectedService.status === 'Warning' ? 'bg-warning' : 'bg-critical'
                  )} />
                  <span className="text-xs font-mono uppercase tracking-widest">{selectedService.status}</span>
                  <span className="text-xs opacity-30">|</span>
                  <span className="text-xs font-mono opacity-50">{selectedService.version}</span>
                </div>
              </div>

              {/* Tabs */}
              <div className="flex border-b border-[var(--color-line)] px-8">
                <button 
                  onClick={() => setActiveTab('overview')}
                  className={cn(
                    "px-4 py-3 text-[10px] font-mono uppercase tracking-widest transition-all border-b-2",
                    activeTab === 'overview' ? "border-ink opacity-100" : "border-transparent opacity-40"
                  )}
                >
                  Overview
                </button>
                <button 
                  onClick={() => setActiveTab('deployments')}
                  className={cn(
                    "px-4 py-3 text-[10px] font-mono uppercase tracking-widest transition-all border-b-2",
                    activeTab === 'deployments' ? "border-ink opacity-100" : "border-transparent opacity-40"
                  )}
                >
                  Deployments
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-8">
                <AnimatePresence mode="wait">
                  {activeTab === 'overview' ? (
                    <motion.div
                      key="overview"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className="space-y-8"
                    >
                      <section>
                        <h4 className="text-[10px] font-mono uppercase tracking-widest opacity-50 mb-4">Resource Allocation</h4>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-4 border border-[var(--color-line)] rounded-xl">
                            <div className="flex items-center gap-2 mb-2 opacity-50">
                              <Cpu className="w-3 h-3" />
                              <span className="text-[10px] font-mono">CPU USAGE</span>
                            </div>
                            <div className="text-xl font-serif">{selectedService.cpu}%</div>
                            <div className="mt-2 h-1 bg-ink/10 rounded-full overflow-hidden">
                              <div className="h-full bg-ink" style={{ width: `${selectedService.cpu}%` }} />
                            </div>
                          </div>
                          <div className="p-4 border border-[var(--color-line)] rounded-xl">
                            <div className="flex items-center gap-2 mb-2 opacity-50">
                              <Database className="w-3 h-3" />
                              <span className="text-[10px] font-mono">MEMORY</span>
                            </div>
                            <div className="text-xl font-serif">{selectedService.memory} MB</div>
                            <div className="mt-2 h-1 bg-ink/10 rounded-full overflow-hidden">
                              <div className="h-full bg-ink" style={{ width: `${(selectedService.memory / 1024) * 100}%` }} />
                            </div>
                          </div>
                        </div>
                      </section>

                      <section>
                        <h4 className="text-[10px] font-mono uppercase tracking-widest opacity-50 mb-4">Performance Metrics</h4>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between p-3 border-b border-[var(--color-line)]">
                            <span className="text-xs">Average Latency</span>
                            <span className="font-mono text-xs">{selectedService.latency}ms</span>
                          </div>
                          <div className="flex items-center justify-between p-3 border-b border-[var(--color-line)]">
                            <span className="text-xs">Error Rate (24h)</span>
                            <span className="font-mono text-xs">{selectedService.errorRate}%</span>
                          </div>
                          <div className="flex items-center justify-between p-3 border-b border-[var(--color-line)]">
                            <span className="text-xs">Throughput</span>
                            <span className="font-mono text-xs">420 req/s</span>
                          </div>
                        </div>
                      </section>

                      <section>
                        <h4 className="text-[10px] font-mono uppercase tracking-widest opacity-50 mb-4">Infrastructure</h4>
                        <div className="space-y-2">
                          <div className="flex items-center gap-3 text-xs">
                            <Globe className="w-4 h-4 opacity-30" />
                            <span>Region: us-east-1 (AWS)</span>
                          </div>
                          <div className="flex items-center gap-3 text-xs">
                            <Box className="w-4 h-4 opacity-30" />
                            <span>Runtime: {selectedService.language}</span>
                          </div>
                          <div className="flex items-center gap-3 text-xs">
                            <Shield className="w-4 h-4 opacity-30" />
                            <span>mTLS: Enabled</span>
                          </div>
                        </div>
                      </section>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="deployments"
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -10 }}
                      className="space-y-6"
                    >
                      <h4 className="text-[10px] font-mono uppercase tracking-widest opacity-50 mb-4">Deployment History</h4>
                      <div className="space-y-4">
                        {deployments.map((dep) => (
                          <div key={dep.id} className="p-4 border border-[var(--color-line)] rounded-xl relative overflow-hidden group">
                            {dep.status === 'Current' && (
                              <div className="absolute top-0 right-0 px-2 py-1 bg-healthy text-ink text-[8px] font-mono uppercase">
                                Current
                              </div>
                            )}
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-xs font-bold font-mono">{dep.version}</span>
                              <span className="text-[10px] font-mono opacity-50">{formatDate(dep.timestamp)}</span>
                            </div>
                            <div className="flex items-center gap-2 text-[10px] opacity-70">
                              <Settings className="w-3 h-3" />
                              <span>Deployed by: <span className="font-bold">{dep.deployer}</span></span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="p-8 border-t border-[var(--color-line)] bg-ink/5 grid grid-cols-2 gap-4">
                <button 
                  onClick={() => handleAction(selectedService.id, 'deploy')}
                  className="flex items-center justify-center gap-2 py-3 bg-ink text-bg rounded-xl text-xs font-medium hover:opacity-90 transition-opacity"
                >
                  <RefreshCw className="w-4 h-4" /> Redeploy
                </button>
                <button 
                  onClick={() => handleAction(selectedService.id, 'rollback')}
                  className="flex items-center justify-center gap-2 py-3 border border-[var(--color-line)] rounded-xl text-xs font-medium hover:bg-ink hover:text-bg transition-all"
                >
                  <ChevronLeft className="w-4 h-4" /> Rollback
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function NavItem({ active, icon, label, onClick }: { active: boolean, icon: React.ReactNode, label: string, onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-xs font-medium transition-all",
        active 
          ? "bg-ink text-bg" 
          : "text-ink/60 hover:bg-ink/5 hover:text-ink"
      )}
    >
      {icon}
      {label}
    </button>
  );
}

function StatCard({ label, value, subValue, icon, trend }: { label: string, value: string, subValue: string, icon: React.ReactNode, trend?: 'up' | 'down' }) {
  return (
    <div className="p-6 border border-[var(--color-line)] rounded-xl bg-white/50 relative overflow-hidden group">
      <div className="flex items-center justify-between mb-4">
        <div className="p-2 bg-ink/5 rounded-lg group-hover:bg-ink group-hover:text-bg transition-colors">
          {icon}
        </div>
        {trend && (
          <div className={cn(
            "text-[10px] font-mono px-2 py-0.5 rounded-full",
            trend === 'up' ? "bg-healthy/10 text-healthy" : "bg-critical/10 text-critical"
          )}>
            {trend === 'up' ? '↑' : '↓'} 12%
          </div>
        )}
      </div>
      <h4 className="text-[10px] font-mono uppercase tracking-widest opacity-50 mb-1">{label}</h4>
      <div className="text-3xl font-serif font-bold mb-1">{value}</div>
      <p className="text-[10px] opacity-40 font-mono">{subValue}</p>
    </div>
  );
}
