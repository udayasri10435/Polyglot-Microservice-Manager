import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Mock Data Generation
  const DOMAINS = [
    "Human Resources", "Finance", "Project Management", 
    "CRM", "Supply Chain", "IT Infrastructure", "Analytics"
  ];
  const LANGUAGES = [
    "Java", "Kotlin", "Go", "Python", "Node.js", 
    "TypeScript", "Rust", "C#", "Elixir", "Scala"
  ];
  const STATUSES = ["Healthy", "Warning", "Critical"];

  const services = Array.from({ length: 1000 }, (_, i) => {
    const domain = DOMAINS[Math.floor(Math.random() * DOMAINS.length)];
    const language = LANGUAGES[Math.floor(Math.random() * LANGUAGES.length)];
    const status = Math.random() > 0.1 ? (Math.random() > 0.1 ? "Healthy" : "Warning") : "Critical";
    
    return {
      id: `svc-${i + 1}`,
      name: `${domain.toLowerCase().replace(/\s+/g, "-")}-${i + 1}`,
      domain,
      language,
      status,
      version: `v1.${Math.floor(Math.random() * 5)}.${Math.floor(Math.random() * 20)}`,
      latency: Math.floor(Math.random() * 200) + 20,
      errorRate: (Math.random() * 2).toFixed(2),
      cpu: Math.floor(Math.random() * 80) + 5,
      memory: Math.floor(Math.random() * 1024) + 128,
      lastDeployed: new Date(Date.now() - Math.random() * 10000000000).toISOString(),
    };
  });

  app.use(express.json());

  // API Routes
  app.get("/api/services", (req, res) => {
    const { page = 1, limit = 20, search = "", domain = "", language = "", status = "" } = req.query;
    
    let filtered = services;
    if (search) {
      filtered = filtered.filter(s => s.name.includes(search as string) || s.id.includes(search as string));
    }
    if (domain) {
      filtered = filtered.filter(s => s.domain === domain);
    }
    if (language) {
      filtered = filtered.filter(s => s.language === language);
    }
    if (status) {
      filtered = filtered.filter(s => s.status === status);
    }

    const start = (Number(page) - 1) * Number(limit);
    const end = start + Number(limit);
    
    res.json({
      total: filtered.length,
      services: filtered.slice(start, end),
      page: Number(page),
      totalPages: Math.ceil(filtered.length / Number(limit))
    });
  });

  app.get("/api/stats", (req, res) => {
    const langStats = LANGUAGES.map(lang => ({
      name: lang,
      count: services.filter(s => s.language === lang).length
    }));

    const domainStats = DOMAINS.map(dom => ({
      name: dom,
      count: services.filter(s => s.domain === dom).length
    }));

    const statusStats = {
      Healthy: services.filter(s => s.status === "Healthy").length,
      Warning: services.filter(s => s.status === "Warning").length,
      Critical: services.filter(s => s.status === "Critical").length,
    };

    res.json({ langStats, domainStats, statusStats });
  });

  app.get("/api/services/:id/versions", (req, res) => {
    const { id } = req.params;
    const service = services.find(s => s.id === id);
    
    if (!service) {
      return res.status(404).json({ error: "Service not found" });
    }

    const DEPLOYERS = ["udayasrimadhushan", "system-bot", "ci-pipeline", "dev-ops-lead"];
    
    const versions = Array.from({ length: 5 }, (_, i) => {
      const date = new Date(new Date(service.lastDeployed).getTime() - i * 86400000 * Math.random());
      return {
        id: `v-${id}-${5 - i}`,
        version: `v1.${Math.floor(Math.random() * 5)}.${Math.floor(Math.random() * 20)}`,
        deployer: DEPLOYERS[Math.floor(Math.random() * DEPLOYERS.length)],
        timestamp: date.toISOString(),
        status: i === 0 ? "Current" : "Superseded"
      };
    });

    res.json(versions);
  });

  app.post("/api/services/:id/action", (req, res) => {
    const { id } = req.params;
    const { action } = req.body;
    // Mock action
    res.json({ success: true, message: `Action ${action} triggered for ${id}` });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
